package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import connectionFactory.ConnectionFactory;
import model.Usuario;

public class UsuarioDao {

	private Connection conexao;
	
	public UsuarioDao() {
		this.conexao = new ConnectionFactory().conectar();
	}
	
	public void insert(Usuario usuario) throws SQLException {
		String sql = "insert into(id, nome, email, telefone, data) values (?,?,?,?,?)";
		PreparedStatement stmt = conexao.prepareStatement(sql);
		
		stmt.setLong(1, usuario.getId());
		stmt.setString(2, usuario.getNome());
		stmt.setString(3, usuario.getEmail());
		stmt.setInt(4, usuario.getTelefone());
		stmt.setDate(5, usuario.getDataRegistro());
		
		stmt.execute();
		stmt.close();
	}
	
}
